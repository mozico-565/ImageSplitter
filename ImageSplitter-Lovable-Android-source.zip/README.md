# Image Splitter — Lovable source on Android

The `web/` directory contains the source exported from the user's Lovable project. The Android application packages a production build of its React interface locally, so the UI comes from the actual project source. The inactive **Fit Screen** button was removed as requested earlier.

The Android layer adds a system image chooser, MediaStore export to `Pictures/ImageSplitter/`, and a system share sheet backed by a read-only content provider. Saved projects and settings use the original project's IndexedDB and localStorage on the device. The app does not request internet access; its web files and Kalam font are included in the APK.

## Build

Install JDK 17, Android SDK 35, Gradle 8.10.2, Node.js 22, and npm. Run `gradle :app:testDebugUnitTest :app:assembleDebug` from this directory. Gradle installs the locked web dependencies, builds `web/dist-mobile`, and packages those files into the Android APK.

GitHub Actions uploads the debug APK as `ImageSplitter-APK` after the same tests and build. The source in `web/` also remains a standalone Lovable project; its original Vite configuration and routes are kept.

Very large source photos and 12,000-pixel exports are limited by the phone's WebView canvas memory. A real device check is recommended for the image picker and share sheet.
