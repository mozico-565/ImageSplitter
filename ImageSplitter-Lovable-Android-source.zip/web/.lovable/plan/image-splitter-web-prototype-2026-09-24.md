# Image Splitter web prototype

## Goal
Build a mobile-first, installable-feeling web prototype that closely follows the supplied hand-drawn interface. The main workspace stays within the phone viewport and supports real image selection, live slicing previews, exact browser-side splitting, downloads, and native sharing where supported.

## Experience
- Recreate the warm paper surface, imperfect ink borders, handwritten hierarchy, illustrated controls, and restrained blue accent from the reference.
- Keep the home workspace fixed to one screen by adapting spacing and preview height to available space.
- Add custom sketch-styled panels and overlays for Projects, Settings, size details, custom dimensions, processing, errors, and completed results.
- Use deliberate draw-on entrance motion and subtle press/selection feedback, with reduced-motion and animation settings respected.

## Functional scope
- Select JPEG, PNG, or WebP through the browser picker and read its real dimensions.
- Split horizontally or vertically into 2–20 exact pieces, distributing remainder pixels without gaps or overlap.
- Support Original, 750 px, 1080 px, and validated custom longest-side output sizing.
- Calculate one shared dimension model for the size popover, preview, generated files, and saved metadata.
- Generate parts off the immediate interaction path, preserving transparency for PNG inputs where possible.
- Download all pieces individually and invoke the device share sheet with multiple files when the browser supports it.
- Persist lightweight project metadata, settings, and source/result references locally without duplicating image data unnecessarily.

## Screens and flows
- **Home:** custom header, picker, split direction, parts slider, output presets, live continuous preview, and Split & Export action.
- **Result:** numbered pieces, dimensions, export status, download/share actions, and Add to Project.
- **Projects:** create, rename, delete with confirmation, open details, remove results, and re-export when the browser still has the source available.
- **Settings:** accent color wheel, recent colors, System/Light/Dark, animations, English/Arabic/Spanish, joining guidance, haptics, reset, and About.

## Technical details
- Implement with React and Canvas APIs inside the existing web stack; no server or account dependency.
- Use semantic design tokens and reusable sketch primitives with deterministic line paths.
- Store preferences and project metadata in browser storage; use IndexedDB for image blobs so projects can survive refreshes.
- Provide translated interface strings and RTL layout for Arabic while preserving meaningful image controls.
- Add route-specific metadata and keep every custom interaction free of generic browser control styling.

## Verification
- Check the full select → configure → preview → split → download/share → save-to-project flow.
- Test 2 and 20 parts, both directions, custom dimensions, settings persistence, and project deletion.
- Inspect at 390×844 and a smaller Android viewport for clipping, overlap, safe-area issues, and unintended scrolling.
