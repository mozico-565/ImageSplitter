# Roadmap

- [x] Build the no-scroll mobile image-splitting workspace
- [x] Add exact browser-side splitting, preview, download, and native sharing
- [x] Add persistent Projects and result management
- [x] Add Settings for accent, theme, animation, language, guidance, and haptics
- [x] Add result, dialogs, popovers, empty, loading, success, and error states
- [x] Verify mobile layout, interactions, and export flow
- [x] Match the supplied phone composition at 390×844 and 430×932
- [x] Upgrade the live preview and every output-size long-press popover
- [x] Re-verify image selection, split directions, slider limits, navigation, and overflow
- [x] Enable natural hidden-scrollbar Home scrolling with a comfortable fixed-height Preview
- [x] Verify the complete Home flow at 390×844 and 430×932
