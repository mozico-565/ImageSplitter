import React from "react";
import { createRoot } from "react-dom/client";
import { ImageSplitter } from "./routes/index";
import "./styles.css";

createRoot(document.getElementById("root")!).render(<ImageSplitter />);
