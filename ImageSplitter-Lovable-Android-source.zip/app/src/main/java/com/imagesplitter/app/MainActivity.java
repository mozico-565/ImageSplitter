package com.imagesplitter.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final int PICK_IMAGE = 1001;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private volatile boolean canGoBack;
    private final ArrayList<Uri> sharing = new ArrayList<>();
    private volatile String saveFolder = "ImageSplitter";

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(250, 249, 246));
        getWindow().setNavigationBarColor(Color.rgb(250, 249, 246));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(250, 249, 246));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !isLocal(request.getUrl());
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!isLocal(uri)) return blocked();
                String path = uri.getPath();
                if (path == null || path.equals("/")) path = "/mobile.html";
                if (path.contains("..") || path.contains("\\")) return blocked();
                try {
                    InputStream stream = getAssets().open(path.substring(1));
                    return new WebResourceResponse(mime(path), "UTF-8", stream);
                } catch (IOException ignored) {
                    return blocked();
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                pick.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/jpeg", "image/png", "image/webp"});
                try { startActivityForResult(Intent.createChooser(pick, "Choose an image"), PICK_IMAGE); }
                catch (Exception error) { fileCallback.onReceiveValue(null); fileCallback = null; return false; }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("https://" + HOST + "/mobile.html");
    }

    private static boolean isLocal(Uri uri) {
        return "https".equals(uri.getScheme()) && HOST.equals(uri.getHost());
    }

    private static WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
    }

    private static String mime(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".js")) return "application/javascript";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
        if (path.endsWith(".ttf")) return "font/ttf";
        if (path.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && fileCallback != null) {
            Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null;
            fileCallback.onReceiveValue(uri == null ? null : new Uri[]{uri});
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (canGoBack) webView.evaluateJavascript("window.dispatchEvent(new Event('androidback'))", null);
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private static String clean(String name) {
        String result = name.replaceAll("[^a-zA-Z0-9._-]", "_");
        return result.length() > 100 ? result.substring(result.length() - 100) : result;
    }

    private static byte[] decoded(String data) {
        int comma = data.indexOf(',');
        if (comma < 0 || !data.substring(0, comma).matches("data:image/(png|jpeg);base64")) throw new IllegalArgumentException("Unsupported image");
        return Base64.decode(data.substring(comma + 1), Base64.DEFAULT);
    }

    private final class AndroidBridge {
        @JavascriptInterface public void setCanGoBack(boolean value) { canGoBack = value; }

        @JavascriptInterface public void setDark(boolean dark) {
            runOnUiThread(() -> {
                int color = dark ? Color.rgb(34, 32, 30) : Color.rgb(250, 249, 246);
                getWindow().setStatusBarColor(color);
                getWindow().setNavigationBarColor(color);
                getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                webView.setBackgroundColor(color);
            });
        }

        @JavascriptInterface public void beginSave() {
            saveFolder = "ImageSplitter/" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        }

        @JavascriptInterface public boolean saveImage(String name, String data) {
            Uri uri = null;
            try {
                String safeName = clean(name);
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                values.put(MediaStore.Images.Media.MIME_TYPE, safeName.endsWith(".png") ? "image/png" : "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + saveFolder);
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return false;
                try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                    if (output == null) throw new IOException("Image destination unavailable");
                    output.write(decoded(data));
                }
                values.clear();
                values.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                return true;
            } catch (Exception error) {
                if (uri != null) getContentResolver().delete(uri, null, null);
                return false;
            }
        }

        @JavascriptInterface public void beginShare() {
            synchronized (sharing) { sharing.clear(); }
        }

        @JavascriptInterface public boolean addShareImage(String name, String data) {
            try {
                File folder = new File(getCacheDir(), "shared-parts");
                if (!folder.exists() && !folder.mkdirs()) return false;
                String safeName = clean(name);
                File file = new File(folder, safeName);
                try (OutputStream output = new FileOutputStream(file)) { output.write(decoded(data)); }
                Uri uri = new Uri.Builder().scheme("content").authority(getPackageName() + ".shared").appendPath(safeName).build();
                synchronized (sharing) { sharing.add(uri); }
                return true;
            } catch (Exception error) { return false; }
        }

        @JavascriptInterface public void finishShare() {
            ArrayList<Uri> files;
            synchronized (sharing) { files = new ArrayList<>(sharing); }
            if (files.isEmpty()) return;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                intent.setType("image/*");
                intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, files);
                ClipData clips = ClipData.newUri(getContentResolver(), "Image parts", files.get(0));
                for (int i = 1; i < files.size(); i++) clips.addItem(new ClipData.Item(files.get(i)));
                intent.setClipData(clips);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent, "Share image parts"));
            });
        }
    }
}
