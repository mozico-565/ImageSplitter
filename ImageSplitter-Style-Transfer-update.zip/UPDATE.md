# ImageSplitter 1.4 — prepared source update

Base: mozico-565/ImageSplitter, main commit e35bb693198f0fcb2fdcc71d7fc42cc262eea7b2.

This archive contains replacement/new files at their repository paths. It is a source update, not an APK.

Native AI Style Transfer workflow: all Style Lab presets, custom style, reference image, 0–100 strength, real server integration, before/after touch comparison, save, regenerate, change style, and use result in splitter. Fourteen fixed style examples are bundled locally. Existing offline splitting/enhancement/background tools are preserved.

Validation completed: hosted API /api/status reports configured; a real Watercolor multipart request with an Android user agent returned HTTP 200 and a 1024×1024 JPEG from FLUX.2 Klein 4B. Generation time and model headers were returned.

Blocked validation: no Android SDK/compiler is available in this workspace. GitHub rejected both git-blob and contents writes with HTTP 403 Resource not accessible by integration. Nothing has been committed to main, no APK has been built, and native emulator tests have not run.

Build workflow compiles debug APK and test APK and runs unit tests. Manual workflow dispatch additionally runs the real native workflow test on an Android API 35 emulator (390×844 and 430×932), producing screenshots and reports. This test consumes one real AI generation; ordinary push builds do not consume AI quota.

Cloudflare secrets remain only on the hosted backend. Native app calls the existing public server without any embedded token. The shared account quota applies to app and website.

Style preview generation prompt set and asset paths are recorded in README.md. Preview images are approximate illustrations, not promised model output.
